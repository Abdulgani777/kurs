package com.example.websecondlab.services;

import java.util.List;

import com.example.websecondlab.services.dtos.RoleDTO;

public interface RoleService {

    /*void addRole(RoleDTO roleDTO);
    List<RoleDTO> getAllRoles();*/

//----------------------------------------------------------------------------------------------------------------------
//    Business

}